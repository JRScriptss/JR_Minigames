ActiveMinigamePromise = nil

lib = exports.JR_Lib:Core()
lib.LoadLocales()