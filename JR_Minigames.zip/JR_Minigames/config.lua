Config = {}

Config.UIImageSource = "ox_inventory/web/images"--Path of your inventory item images, examples:
    --QBCore: qb-inventory/html/images
    --Ox: ox_inventory/web/images