
![JR_Minigames](https://github.com/JRScriptss/JR_Minigames)

# JR_Minigames
**A resource that provides various minigames for other JRScript resources.
You are also free to include this in your own releases or use it in your own projects.**

## Available Minigames
- **Lockpicking**
  
  	` exports.JR_Minigames:StartLockpick(pickCount, eventStep, breakChance) `
- **Hacking**
  
	` exports.JR_Minigames:StartHacking(count,  rememberTime,  completeTime) `
- **Looting**
  
	`exports.JR_Minigames:StartLooting(items,  timeToLoot,  size,  callback) `
- **Typewriter**

	`exports.JR_Minigames:StartTypewriter(count, completeTime)`
- **Pressure Bar**

	` exports.JR_Minigames:StartPressureBar(breakLine, speed) `

You can also find examples on what arguments to send inside of client files in the bottom.

## Check us out!
You can reach us on our [Discord](https://discord.gg/EUFAUs2X)
