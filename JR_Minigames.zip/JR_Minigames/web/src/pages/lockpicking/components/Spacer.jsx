function Spacer() {
    return (
        <div className="h-full w-6 bg-white" />
    )
}

export default Spacer;