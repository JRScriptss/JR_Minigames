export const isEnvBrowser = () => !window.invokeNative

export const noop = () => {}