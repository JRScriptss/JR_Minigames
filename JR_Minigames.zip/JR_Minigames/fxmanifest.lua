fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'JRScripts'
version '1.0.0'


shared_scripts { 'config.lua' }
client_scripts { "client/*" }

files { 'locales/*.json', "web/build/**/*" }

dependency 'JR_Lib'

ui_page "web/build/index.html"
